# SOA-HQA
Home Quick Answerer para SOA 

Para buildear el proyecto es necesario crear el archivo local.properties para indicar el path del SDK:

El archivo debe contener la propertie "sdk.dir" y apuntar al SDK. Ejemplo:


    sdk.dir=C\:\\Users\\User\\AppData\\Local\\Android\\Sdk